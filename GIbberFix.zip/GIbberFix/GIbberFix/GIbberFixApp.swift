//
//  GIbberFixApp.swift
//  GIbberFix
//
//  Created by Itai Henig on 19/05/2025.
//

import SwiftUI

@main
struct GIbberFixApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
