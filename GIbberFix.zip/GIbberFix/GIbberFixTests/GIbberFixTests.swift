//
//  GIbberFixTests.swift
//  GIbberFixTests
//
//  Created by Itai Henig on 19/05/2025.
//

import Testing
@testable import GIbberFix

struct GIbberFixTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
